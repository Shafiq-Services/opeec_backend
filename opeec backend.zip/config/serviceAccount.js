module.exports={
  type: "service_account",
  project_id: "opeec-8239c",
  private_key_id: "5c0b0298c8e5abb2d2af1508ad1870987a24ebe6",
  private_key: "-----BEGIN PRIVATE KEY-----\nMIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQC5Bxwfy549Mgri\n9wN1rBpzF/LxHUFfwkglFsxDWY36X5+b6LZ9K431ifcXHsZukuBRU5AgWlfxshpy\nEXUT46ilqv+pgWiPafs4EAWiJPCZDFXRjVuquOrN1pAjq1FPQNbBLB7sWuvgSYJ0\nlptUtIS1aVO1Z+OZPOcEWhyY9wRHz4quZ8VMMhWQJcgIKHvr7Z+PkDbLs2oiPFKV\n02UWp3+pDSxjUIePuEg2tFE+AuUhKHCBrXnz5bOApo4a0cM/2zBV90KBSiMBZySH\nqu+aUZ+Rf446Lhs1NdSOSH2eunZi6qY5JXNwhkO9vteoWYZHQCnxmU3ZbZZVFJfP\nMd54/O5HAgMBAAECggEACGqHX/beEsCE+D/uG1shtNyBA3CmOZnXuEAqOGIJcDsL\nQoc6TcU+Zs3IvHd85SivJWPcqWwSlf7Y7xlWLvprAGYfzPEC9YsHj0xDRVXSz9Nc\nz/RTGBfjLku1MLopL6auXgkIuw2DrycI1Q7Ir/iqFKpe0WCRXLYFeBA1Psv1mOKG\n797asw4BfPorqruGRvC1Wl3Sihdx1lbF+ootqoWtGMO7ZYv70en9o7iB6TpzRyLF\n6ZwFs6qx+zoaGI3i4znatf53WHcubYbzFpZwt+RgRMDyJh1tuBwu11dAuboOmjoc\no8qiQ9Ytj9XkfIeihX3Esf37SHW9ZzWhWIC05Z0qyQKBgQDxOaYUZxucdSJK+BKC\n+JEGr488+N83PIbJO6TXEHqUFwmx44u75v5zSKuMexmDyxfE5d5GTT4Q2eFxmWxY\nDAjijM0aa+4s57beGLYftp2h3wngKd5hMQpRSOeSSTtLpR1Vb8Zc3Fgk8cE0ZsCV\n2zB0dUkkO4YmqgqIMbaNo+/TJQKBgQDEXEytYbiQCUQvRDJloZubGfS0GT/lHHJE\nc6yE3GjlLXdQIz8Nnx+4cX/pdCGWGbBl1+3VTHMb1LUGSvOX71BKiRXGRm+M7QAA\nkbDxWmCXJggx4Ul4ygocWFlxN+NFgr42bjtxvXL1qRXpz6C/5AHH4kbzN/c/1r94\nzaeCGSV1+wKBgQDaK0KLB2oQilwWo+DSNY+tFVEeWxQ/N+3LyLbgkBXdJCzvh5ZU\nvql5iMsmxhsgeKmpuiDbQncU9IoSnSlBRLkwdRn3gJAsavGYU488hYRx53BeHl/z\nVVA4jhBq3PLVCqPKJsqoJ91MpJ4SD7C0mEZtvboGHBPLmlTmMtghqJh6RQKBgHx7\ncxS7jbCqXzKDzltFr4sNUmdWVn5doUcp+eWkgU9AmpIQNinhhc99DLUoLR6mHIED\n+b+uHo83MqfRnknkqgcGjupKvu8dVFIICp+HRxKrRqiwhM5xbyV3EQTIhGkNsJ57\nFW5OxvFcBwtZ2DOuTT61gXsxMKqk7m+cGKROYsQ/AoGBAM3X85AXB/bKlyaTWkcV\n9YySYPrjfs157cC4IE36GJ/kB9zFSBbfkcgANGMQwfD/IyMv+ZBRLuakcWuZ6bU+\n9rOVoWrYHwmmW55QPkgtHmzTdEyP7MdgnO9VU1j89mRwjFsnhCJ6fqO5pEpr64S+\nezUHFudfp2ltZuioJN5JkjAJ\n-----END PRIVATE KEY-----\n",
  client_email: "firebase-adminsdk-fbsvc@opeec-8239c.iam.gserviceaccount.com",
  client_id: "115598423695163387487",
  auth_uri: "https://accounts.google.com/o/oauth2/auth",
  token_uri: "https://oauth2.googleapis.com/token",
  auth_provider_x509_cert_url: "https://www.googleapis.com/oauth2/v1/certs",
  client_x509_cert_url: "https://www.googleapis.com/robot/v1/metadata/x509/firebase-adminsdk-fbsvc%40opeec-8239c.iam.gserviceaccount.com",
  universe_domain: "googleapis.com"
}
